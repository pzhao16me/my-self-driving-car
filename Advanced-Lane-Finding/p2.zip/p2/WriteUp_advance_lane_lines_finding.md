# Advanced Lane Finding Project
The goals / steps of this project are the following:
    Compute the camera calibration matrix and distortion coefficients given a set of chessboard images.
    Apply a distortion correction to raw images.
    Use color transforms, gradients, etc., to create a thresholded binary image.
    Apply a perspective transform to rectify binary image ("birds-eye view").
    Detect lane pixels and fit to find the lane boundary.
    Determine the curvature of the lane and vehicle position with respect to center.
    Warp the detected lane boundaries back onto the original image.
    Output visual display of the lane boundaries and numerical estimation of lane curvature and vehicle
    position.
## Rubric Points

### 1. Have the camera matrix and distortion coefficients been computed correctly andchecked on one of the calibration images as a test?
The code for this step is contained in the CameraCalTools.py,line 50,where i get the distortion  coeficients

I start by build a class , which will be have the function points to get distortion coedfficients,which i can use 
do undistort raw image,achive to change raw image to bird-likes view. In which ,i use cv2.calibrateCamera(),
cv2.undistort(), cv2.warpPerspective(). The final undistorted result as below:
    

![](output_images/undistorted5.jpg)

## Pipeline (single images )
1. Has the distortion correction been correctly applied to each image?
To demonstrate this step, I will describe how I apply the distortion correction to one of the test images like this
one:

![](output_images/undistorted5.jpg)
2. Has a binary image been created using color transforms, gradients or other methods?Oooh, binary image... you mean like this one? (note: this is not from one of the test images)
###  gradient thrshold process
![](output_images/gradient_thresholds5.jpg)

### bird-eyes like view
![](output_images/perspective_warp5.jpg)

The code for my perspective transform is includes a function called  warp_to_overhead_perspective() in the 
CameraCalTools.py line 131

src points: [[ 287.  670.]
 [ 543.  485.]
 [ 743.  485.]
 [1032.  670.]]
/t
dst points: [[ 187.  720.]
 [ 187.    0.]
 [1082.    0.]
 [1082.  720.]]
3 . Have lane line pixels been identified in the rectified image and fit with a polynomial?

some usful functions  in findLaneTools.py file helps a lot

![](output_images/test5_lanes_finding.jpg)


![](output_images/test5_found_lanes_centoid.jpg)
4. Having identified the lane lines, has the radius of curvature of the road been estimated?
And the position of the vehicle with respect to center in the lane?
Yep, sure did!

## Pipeline (video)
1. Does the pipeline established with the test images work to process the video?
yes, in unload.zip file

## Discussion
I am a data mining engineer and I feel that this project has been difficult and has been submitted many times, with errors every time. It may be because I just want to get the project done. Ok, I admit that I have a lot of troubles in my work and life. I submitted it again today. In the last complicated scene, the whole code is a bit bad. I hope the staff can give some reference materials. Because I haven't been exposed to image and video processing before, but the reference material for this course is limited to the opencv documentation and a machine vision course. I am thinking, will it be a little less?