import numpy as np

class CameraIamge:
    """
        the class has all the images needed  in the lane line finding project


    """
    def __init__(self,imageIn, cameraCal,changeThreshold=False):

        # The current image
        self.img = imageIn

        # the parameters
        self.original_image = imageIn
        self.cal = cameraCal
        self.changeThreshold = changeThreshold

        # the status parameters
        self.distorded = True
        self.threshold_applied = False
        self.transformed = False

    def abs_sobel_thresh(self, img, orient='X', sobel_kernel =3, thresh=(0, 255)):
        """
            apply gradient Sobel threshold in the specified direction
        :param img: image
        :param orient:  direciton
        :param sobel_kernel:  kernal size
        :param thresh: thresh
        :return: binary_output
        """
        if orient == "X":
            abs_sobel= np.absolute(cv2.Sobel(img, cv2.CV_64F, 1, 0))
        if orient == "Y":
            abs_sobel= np.abs(cv2.Sobel(img,cv2.CV_64F), 0, 1)

        # rescale to 8 bit integer
        scaled_sobel = np.uint8(255 * abs_sobel / np.max(abs_sobel))

        # create a copy and apply  the threshold
        binary_output = np.zeros_like(scaled_sobel)

        # use inclusive threshold
        binary_output[(scaled_sobel >= thresh[0]) & (scaled_sobel <= thresh[1])] = 1
        return binary_output


    def mag_thresh(self, img, sobel_kernal =3, thresh =(0,255)):

        # apply a gradient magnitude threshold
        sobelx = cv2.Sobel(img, cv2.CV_64F, 1, 0, ksize=sobel_kernal)
        sobely = cv2.Sobel(img, cv2.CV_64F, 0, 1, ksize=sobel_kernal)

        # calculate the gradient magnitude
        gradmag = np.sqrt(sobelx**2 + sobely**2)

        # rescale to 8 bit integer
        scale_rate = np.max(gradmag) / 255

        gradmag = (gradmag/scale_rate).astype(np.uint8)

        # create a binary image and apply the threshold
        binary_output = np.zeros_like(gradmag)
        binary_output[(gradmag >= thresh[0]) & (gradmag <= thresh[1])] = 1

        return binary_output

    def dir_thresh(self, img, sobel_kernal=3, thresh=(0, np.pi/2)):

        # apply a  directional gradient threshold
        sobelx = cv2.Sobel(img, cv2.CV_64F, 1, 0, ksize=sobel_kernal)
        sobely = cv2.Sobel(img, cv2.CV_64F, 0, 1, ksize=sobel_kernal)

        # take the absolute value of the gradient direction, apply a threshold
        dir_img = np.arctan2(np.absolute(sobelx), np.absolute(sobely))
        binary_output = np.zeros_like(dir_img)
        binary_output[(dir_img >= thresh[0]) & (dir_img <= thresh[1])] = 1
        return binary_output

    def hls_choose(self, chan, thresh=(0,255)):
        #  apply a threshold on a given channel
        binary_output = np.zeros_like(chan)
        binary_output[(chan >= thresh[0]) & (chan <= thresh[1])] = 1
        return binary_output

    def hls(self):
        # convert RGB to HLS
        return cv2.cvtColor(self.img, cv2.COLOR_RGB2HLS)

    def gray(self):
        # convert RGB to gray scale
        return cv2.cvtColor(self.img, cv2.COLOR_RGB2GRAY)

    def color_selct(self, color_image, thresh=[(0, 0),(0, 0),(0, 0)]):

        # apply color threshold on a given image
        #extract the color channel
        r = color_image[:, :, 0]
        g = color_image[:, :, 1]
        b = color_image[:, :, 2]

        # combine into single channel
        binary_min = np.zeros_like(r)
        binary_min[(r >= thresh[0][0]) & (r <= thresh[0][1])
                   &(g >= thresh[1][0]) & (g <= thresh[1][1])
                   &(b >= thresh[2][0]) & (b <= thresh[2][1])] = 1
        return binary_min

    def undistort_image(self):
        # undistord an image
        if self.distorded:
            self.img = cameraCal.undistort_image(self.img)
            self.distorded = False

    def apply_threshold(self, plot = False):

        # apply combine threshold to a given image
        if not self.threshold_applied:

            # set channel
            hls = self.hls()
            h_channel = hls[:, :, 0]
            s_channel = hls[:, :, 2]
            h_select = self.hls_choose(h_channel, thresh=(0, 30))
            s_select = self.hls_choose(s_channel, thresh=(100, 255))

            if self.changeThreshold:
                # get the pure yellow , white sections
                yellow = self.color_selct(self.img, thresh=[(140, 255), (140, 255), (0, 120)])
                white  = self.color_selct(self.img, thresh=[(200, 255), (200, 255), (200, 255)])

                color_select = np.zeros_like(yellow)
                color_select[(yellow ==1) |(white == 1)] = 1

            #use the thresholds to find lane lines
            sobelx = self.abs_sobel_thresh(self.gray(), orient='X', thresh=(30, 100))
            sobel_dir = self.dir_thresh(self.gray(), sobel_kernal=15, thresh=(0.7, 1.3))

            sobel_combine = np.zeros_like(sobel_dir)
            sobel_combine[(sobelx == 1) & (sobel_dir == 1)] = 1



            # combine  all the thresholds

            combine_binary = np.zeros_like(h_select)
            combine_binary[((h_select == 1) & (s_select ==1)) |
                               (sobel_combine == 1)] = 1

                # plot when need
            if plot:
                plt.subplot(2, 2, 1)
                plt.imshow(sobel_combine, cmap='gray')
                plt.title("sobel  combine")
                plt.subplot(2, 2, 2)
                plt.imshow(h_select, cmap='gray')
                plt.title("h channel")
                plt.subplot(2, 2, 3)
                plt.imshow(s_select, cmap='gray')
                plt.title("s  channel")
                plt.subplot(2, 2, 4)
                plt.imshow(combine_binary, cmap='gray')
                plt.title('combine')
                plt.show()
            self.img = combine_binary
            self.threshold_applied = True

    def perspective_transform(self):

        # transform an image to bird_eyes  like view
        if not self.transformed:
            self.img = cameraCal.warp_to_overhead_perspective(self.img)
            self.transformed = True

    def apply_full_pipeline(self):
        # apply all the step in the pipeline
        self.undisort_image()
        self.apply_threshold()
        self.perspective_transform()
